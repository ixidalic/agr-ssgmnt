# Ageera DevOps Home Assignment

Local automated Kubernetes cluster, containerized Node.js application, CI pipeline, Prometheus and Grafana observability.

## Architecture

```text
                   GitHub
                      |
                  GitHub Actions
                  /           \
               test      build + push
                            |
                           GHCR

Local machine
+-------------------------------------------------------+
| Docker                                               |
|  +---------------- kind: ageera-devops ------------+ |
|  |                                                   | |
|  |  ageera namespace                                | |
|  |    Deployment (2 replicas)                       | |
|  |       |                                           | |
|  |    ClusterIP Service ----> /metrics              | |
|  |       |                    /health                | |
|  |       |                    /ready                 | |
|  |       |                                           | |
|  |    ServiceMonitor <------------------- Prometheus | |
|  |                                                   | |
|  |  monitoring namespace                             | |
|  |    kube-prometheus-stack                         | |
|  |       Prometheus ---------> Grafana               | |
|  |                                |                  | |
|  |                        Ageera App dashboard       | |
|  +---------------------------------------------------+ |
+-------------------------------------------------------+
```

## Why these choices

### kind
kind runs Kubernetes nodes as containers and is specifically intended for local Kubernetes and CI use. It keeps the assignment portable and avoids a VM-heavy local cluster. The setup script creates a named cluster and waits for the control plane before proceeding.

### Kubernetes manifests + Kustomize
The application deployment is intentionally plain Kubernetes YAML with a `kustomization.yaml`. This keeps the resource model visible to a reviewer while avoiding Helm-templating overhead for one small application.

### ServiceMonitor
The application exposes Prometheus-format metrics itself. A `ServiceMonitor` makes the scrape configuration declarative and Kubernetes-native, rather than hiding Prometheus configuration inside an opaque hand-written ConfigMap.

### kube-prometheus-stack
The assignment asks for Prometheus + Grafana. The `kube-prometheus-stack` Helm chart provides the Prometheus Operator, Prometheus, Grafana, and the CRDs required for `ServiceMonitor`. The chart version is pinned in `scripts/setup.sh` for reproducible local setup.

### Local image loading
The local setup builds the image and loads it into kind instead of requiring Docker Hub/GHCR credentials. This makes the local demo self-contained. CI separately publishes the image to GHCR.

## Containerization

The Dockerfile uses two stages:

1. `build`: installs the complete lockfile-resolved dependency tree and compiles TypeScript.
2. `runtime`: installs production dependencies only and copies the compiled `dist` output.

The runtime uses the `node` user, drops Linux capabilities in Kubernetes, disallows privilege escalation, and uses a read-only root filesystem. Kubernetes supplies probes and resource requests/limits.

## CI

The workflow has exactly two jobs:

- `test`: `npm ci`, Jest tests, and TypeScript compilation.
- `build-and-push`: runs after tests pass, logs into GHCR using the built-in `GITHUB_TOKEN`, generates image tags, and builds/pushes the Docker image.

The repository must have GitHub Actions allowed to write packages. For a private repository, package visibility and repository permissions may need to be adjusted in GitHub.

## Prerequisites

Install and place these commands in `PATH`:

- Docker Desktop / Docker Engine
- kind
- kubectl
- Helm

The setup script checks these prerequisites and does not silently install them, because OS package management is an entirely different carnival across Windows, Linux and macOS.

## One-command local setup

From the repository root:

```bash
./scripts/setup.sh
```

The script:

1. Creates the kind cluster if it does not already exist.
2. Builds the application image.
3. Loads the image into kind.
4. Applies the Kubernetes resources.
5. Waits for the application rollout.
6. Installs the pinned kube-prometheus-stack release.
7. Waits for Grafana and Prometheus.
8. Prints the commands for accessing the application, Grafana and Prometheus.

## Validation

Application:

```bash
kubectl get pods -n ageera
kubectl get servicemonitor -n ageera
kubectl port-forward -n ageera svc/devops-assignment-app 3000:3000
```

In another terminal:

```bash
curl http://127.0.0.1:3000/health
curl http://127.0.0.1:3000/ready
curl http://127.0.0.1:3000/metrics
```

Prometheus:

```bash
kubectl port-forward -n monitoring svc/kube-prometheus-stack-prometheus 9090:9090
```

Then verify the target is present and query:

```promql
up{service="devops-assignment-app"}
sum(rate(http_requests_total[5m]))
histogram_quantile(0.95, sum by (le) (rate(http_request_duration_seconds_bucket[5m])))
```

Grafana:

```bash
kubectl port-forward -n monitoring svc/kube-prometheus-stack-grafana 3001:80
```

Login with `admin` / `admin` for this local-only assignment environment and open the `Ageera App Observability` dashboard.

## Cleanup

```bash
./scripts/teardown.sh
```

## Repository hygiene

Do not commit generated dependencies or build output. The supplied `.gitignore` already excludes `node_modules`, `dist`, log files and `.env`. The committed source of truth should be `src`, `package.json`, `package-lock.json`, configuration, manifests, dashboard and scripts.

## AI usage

AI was used as an implementation accelerator and review aid. Architectural decisions, Kubernetes resources, CI behavior, security settings and observability queries should be understood and explainable by the candidate. The repository intentionally keeps the generated system small enough to audit manually.
